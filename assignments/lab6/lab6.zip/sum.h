/*******************************************************************************
 * Name        : sum.h
 * Author      : Joshua Schmidt and Matt Evanago
 * Date        : 3/6/20
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 * Description : DLL's
 ******************************************************************************/

#ifndef SUM_H_
#define SUM_H_

/* Function prototype */
int sum_array(int *array, const int length);

#endif
